import os

template = '''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DRC SATU-{letter}</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700&display=swap" rel="stylesheet">
  <style>
    body {{
      margin: 0;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #f0f0f0;
    }}
    .center-text {{
      color: red;
      font-size: 6rem;
      font-family: 'Poppins', sans-serif;
      font-weight: 700;
      background-color: #ffe5e5;
      padding: 20px 40px;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }}
  </style>
</head>
<body>
  <div class="center-text">DRC SATU-{letter}</div>
</body>
</html>'''

for letter in ['A', 'B', 'C', 'D', 'E', 'F']:
    folder_name = f'{letter}'
    os.makedirs(folder_name, exist_ok=True)
    with open(os.path.join(folder_name, 'index.html'), 'w') as f:
        f.write(template.format(letter=letter))

